本软件的管理员id和密码均是12345

以下是展示效果

<img src="Demo/auc2-active-listing.gif" width=80%/>

### 创建新产品

<img src="Demo/auc1-create-new-listing.gif" width=80%/>

### 贩卖产品

<img src="Demo/auc3-sold-listing.gif" width=80%/>

### 投标和评价

<img src="Demo/auc4-bid-and-comment.gif" width=80%/>

### 看表

<img src="Demo/auc5-watchlist.gif" width=80%/>


### 种类
<img src="Demo/auc6-category.gif" width=80%/>


